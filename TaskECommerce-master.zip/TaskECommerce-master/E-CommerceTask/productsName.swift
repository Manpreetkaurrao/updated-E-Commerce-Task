//
//  productsName.swift
//  E-CommerceTask
//
//  Created by Sierra 4 on 16/02/17.
//  Copyright © 2017 codebrew2. All rights reserved.
//

import Foundation
class productsName
{
    var name : String?
    var price : String?
    var description : String?
    init(name : String?, price : String?, description : String?)
    {
        self.name = name
        self.price = price
        self.description = description
    }
}
