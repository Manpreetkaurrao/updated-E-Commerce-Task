//
//  categoriesName.swift
//  E-CommerceTask
//
//  Created by Sierra 4 on 15/02/17.
//  Copyright © 2017 codebrew2. All rights reserved.
//

import Foundation
class categoriesName
{
    var name : String?
    init(name : String?)
    {
        self.name = name
    }
}
