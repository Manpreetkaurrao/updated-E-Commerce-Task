//
//  Categorylist+CoreDataClass.swift
//  E-CommerceTask
//
//  Created by Sierra 4 on 14/02/17.
//  Copyright © 2017 codebrew2. All rights reserved.
//

import Foundation
import CoreData

@objc(Categorylist)
public class Categorylist: NSManagedObject {

}
